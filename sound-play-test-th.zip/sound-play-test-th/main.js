/*
  #-- NodeJs sound play test based on HTTP and Websocket.
  #-- Developed by Tharusha Udana.
*/

const app = require('express')();
const http = require('http').Server(app);
const io = require('socket.io')(http);
const soundplay = require('sound-play');
const IP = require('ip');
const path = require('path');

//--- colors ---
const COLOR_BLCK = "#000000";
const COLOR_HEAD = "#e5e510";
const COLOR_INFO = "#ffffff";
const COLOR_SUCC = "#209763";
//--------------

//---- Handle HTTP Requests
app.get('/', async function (req, res) {
    res.sendFile(__dirname + '/asset/index.html');
});

app.get('/jquery.js', async function (req, res) {
  res.sendFile(__dirname + '/asset/jquery.js');
});
app.get('/socket.io.js', async function (req, res) {
  res.sendFile(__dirname + '/asset/socket.io.js');
});

//---- Handle Websocket
io.on('connection', (socket) => {
  emitOutput("Starting broadcast...", COLOR_HEAD, false, socket);
  emitOutput("NodeJs sound play test based on http and Websocket. Developed by Tharusha Udana.", COLOR_BLCK, true, socket);
  
  socket.on('playsound', msg => {
    emitOutput("Player started...", COLOR_INFO, false);
    playSound();
  });
});

function emitOutput(output, color, ishighlight, sock = io) {
  var array = {
    message: output,
    color: color,
    ishighlight: ishighlight
  };
  sock.emit('output', JSON.stringify(array));
}

function playSound() {
    soundplay.play(path.join(__dirname, 'asset', 'bell.mp3')).then((response) => emitOutput("Sound player finished.", COLOR_SUCC, false));
}


http.listen(process.env.PORT || 3000, () => {
  console.log('Server running at http://' + IP.address() + ':3000');
});
//app.listen(process.env.PORT || 3000, () => console.log('Listening on http://' + IP.address() + ':3000'));